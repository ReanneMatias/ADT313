import { useReducer, useState } from 'react';
import data from './problem8mock_data.json';


function foodReducer(state, action) {
  switch (action.type) {
    case 'CREATE':
      return [...state, action.payload]; // Adds new food to the list
    case 'UPDATE':
      return state.map((food) =>
        food.id === action.payload.id ? { ...food, ...action.payload } : food
      ); // Updates an existing food
    case 'DELETE':
      return state.filter((food) => food.id !== action.payload.id); 
    default:
      return state;
  }
}

export default function Problem8() {
  const [foods, dispatch] = useReducer(foodReducer, data); 
  const [selected, setSelected] = useState({
    id: null,
    food_name: '',
    price: '',
    expiration_date: '',
    calories: '',
  });

  // Handles the Edit button click
  const handleEdit = (food) => {
    setSelected(food); 
  };

  const handleDelete = (id) => {
    dispatch({ type: 'DELETE', payload: { id } }); 
  };

  
  const handleClear = () => {
    setSelected({
      id: null,
      food_name: '',
      price: '',
      expiration_date: '',
      calories: '',
    });
  };

  
  const handleSave = () => {
    if (selected.id) {
      // If the food has an id, update the existing food
      dispatch({ type: 'UPDATE', payload: selected });
    } else {
      // If there's no id, create a new food item
      const newFood = {
        id: Date.now(), // Generate a unique id based on the current timestamp
        food_name: selected.food_name,
        price: selected.price,
        expiration_date: selected.expiration_date,
        calories: selected.calories,
      };
      dispatch({ type: 'CREATE', payload: newFood }); // Dispatches CREATE action to add the new food
    }
    handleClear(); // Clears the form after saving
  };

  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setSelected((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          Food Name:{' '}
          <input
            type='text'
            name='food_name'
            value={selected.food_name}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Price:{' '}
          <input
            type='text'
            name='price'
            value={selected.price}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Expiration Date:{' '}
          <input
            type='text'
            name='expiration_date'
            value={selected.expiration_date}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Calories:{' '}
          <input
            type='text'
            name='calories'
            value={selected.calories}
            onChange={handleInputChange}
          />
        </div>

        <button type='button' onClick={handleSave}>
          Save
        </button>
        <button type='button' onClick={handleClear}>
          Clear
        </button>
      </div>
      <div className='table-container'>
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>Food Name</th>
              <th>Price</th>
              <th>Expiration Date</th>
              <th>Calories</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {foods.map((food) => (
              <tr key={food.id}>
                <td>{food.food_name}</td>
                <td>{food.price}</td>
                <td>{food.expiration_date}</td>
                <td>{food.calories}</td>
                <td>
                  <button type='button' onClick={() => handleEdit(food)}>
                    Edit
                  </button>
                  <button type='button' onClick={() => handleDelete(food.id)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}



