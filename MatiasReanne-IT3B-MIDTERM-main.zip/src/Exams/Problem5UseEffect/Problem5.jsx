import { useEffect, useRef, useState } from 'react';
import Loading from './Problem5Components/Loading';
export default function Problem5() {
  const [isLoading, setIsLoading] = useState(true);
  const [isIdle, setIsIdle] = useState(true);
  const typingTimeoutRef = useRef(null);

  
   useEffect(() => {
    const loadingTimer = setTimeout(() => {
      setIsLoading(false); 
    }, 3000);

  return () => clearTimeout(loadingTimer); 
}, []);
const handleUserTyping = () => {
  setIsIdle(false);

  if (typingTimeoutRef.current) {
    clearTimeout(typingTimeoutRef.current);
  }
  typingTimeoutRef.current = setTimeout(() => {
    setIsIdle(true); 
  }, 3000);
};

return (
  <>
    {isLoading ? (
      <Loading />
    ) : (
      <div style={{ display: 'block' }}>
        Input: <input type="text" onInput={handleUserTyping} />
        <p>{isIdle ? 'User is idle...' : 'User is typing...'}</p>
      </div>
    )}
  </>
);
}

