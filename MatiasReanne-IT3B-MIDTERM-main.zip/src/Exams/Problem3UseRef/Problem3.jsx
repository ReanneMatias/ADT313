import { useRef } from "react";
function Problem3() {

  const inputRefs = useRef([]);

  const handleButtonClick = () => {
    for (let i = 0; i < inputRefs.current.length; i++) {
      if (inputRefs.current[i].value.trim() === '') {
        inputRefs.current[i].focus();
        break;
      }
    }
  };

  return (
    <>
      <div style={{ display: 'block' }}>
        Input 1: <input type='text' ref={(el) => (inputRefs.current[0] = el)}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 2: <input type='text' ref={(el) => (inputRefs.current[1] = el)}/> 
      </div>
      <div style={{ display: 'block' }}>
        Input 3: <input type='text' ref={(el) => (inputRefs.current[2] = el)} />
      </div>
      <div style={{ display: 'block' }}>
        Input 4: <input type='text' ref={(el) => (inputRefs.current[3] = el)} />
      </div>
      <div style={{ display: 'block' }}>
        Input 5: <input type='text' ref={(el) => (inputRefs.current[4] = el)} />
      </div>
      <div style={{ display: 'block' }}>
        Input 6: <input type='text' ref={(el) => (inputRefs.current[5] = el)} />
      </div>
      <div style={{ display: 'block' }}>
        Input 7: <input type='text' ref={(el) => (inputRefs.current[6] = el)} />
      </div>
      <div style={{ display: 'block' }}>
        Input 8: <input type='text' ref={(el) => (inputRefs.current[7] = el)} />
      </div>
      <div style={{ display: 'block' }}>
        Input 9: <input type='text' ref={(el) => (inputRefs.current[8] = el)} />
      </div>
      <div style={{ display: 'block' }}>
        Input 10: <input type='text' ref={(el) => (inputRefs.current[9] = el)} />
      </div>
      <button type='button' onClick={handleButtonClick}>I'm a button</button>
    </>
  );
}

export default Problem3;
