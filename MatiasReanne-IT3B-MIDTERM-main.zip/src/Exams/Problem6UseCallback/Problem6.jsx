import { useCallback, useState } from 'react';
import data from './MOCK_DATA.json';

export default function Problem6() {
  const [cars, setCars] = useState(data); 
  const [selected, setSelected] = useState(null); 
  const [vin, setVin] = useState('');
  const [make, setMake] = useState('');
  const [model, setModel] = useState('');
  const [year, setYear] = useState('');
  const [color, setColor] = useState('');

 
  const handleEdit = useCallback((car) => {
    setSelected(car);
    setVin(car.vin);
    setMake(car.make);
    setModel(car.model);
    setYear(car.year);
    setColor(car.color);
  }, []);

  
  const handleDelete = useCallback((vinToDelete) => {
    setCars((prevCars) => prevCars.filter((car) => car.vin !== vinToDelete));
  }, []);

  
  const handleSave = useCallback(() => {
    const newCar = { vin, make, model, year, color };
    setCars((prevCars) => [...prevCars, newCar]);
    // Reset form after saving
    setVin('');
    setMake('');
    setModel('');
    setYear('');
    setColor('');
  }, [vin, make, model, year, color]);

  
  const handleUpdate = useCallback(() => {
    if (!selected) return; 

    const updatedCar = { vin, make, model, year, color };
    setCars((prevCars) =>
      prevCars.map((car) => (car.vin === selected.vin ? updatedCar : car))
    );
    
    setVin('');
    setMake('');
    setModel('');
    setYear('');
    setColor('');
    setSelected(null); 
  }, [vin, make, model, year, color, selected]);

 
  const handleClear = useCallback(() => {
    setVin('');
    setMake('');
    setModel('');
    setYear('');
    setColor('');
    setSelected(null); // Clear selected car
  }, []);

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          VIN:{' '}
          <input
            type='text'
            value={vin}
            onChange={(e) => setVin(e.target.value)}
          />
        </div>
        <div style={{ display: 'block' }}>
          Make:{' '}
          <input
            type='text'
            value={make}
            onChange={(e) => setMake(e.target.value)}
          />
        </div>
        <div style={{ display: 'block' }}>
          Model:{' '}
          <input
            type='text'
            value={model}
            onChange={(e) => setModel(e.target.value)}
          />
        </div>
        <div style={{ display: 'block' }}>
          Year:{' '}
          <input
            type='text'
            value={year}
            onChange={(e) => setYear(e.target.value)}
          />
        </div>
        <div style={{ display: 'block' }}>
          Color:{' '}
          <input
            type='text'
            value={color}
            onChange={(e) => setColor(e.target.value)}
          />
        </div>
        <button type='button' onClick={handleSave}>
          Save
        </button>
        <button type='button' onClick={handleClear}>
          Clear
        </button>
      </div>

      <div className='table-container'>
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>VIN</th>
              <th>Make</th>
              <th>Model</th>
              <th>Year</th>
              <th>Color</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {cars.map((car) => (
              <tr key={car.vin}>
                <td>{car.vin}</td>
                <td>{car.make}</td>
                <td>{car.model}</td>
                <td>{car.year}</td>
                <td>{car.color}</td>
                <td>
                  <button type='button' onClick={() => handleEdit(car)}>
                    Edit
                  </button>
                  <button type='button' onClick={() => handleDelete(car.vin)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

