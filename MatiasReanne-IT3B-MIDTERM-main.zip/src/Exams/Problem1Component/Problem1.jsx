import React from 'react';

const Problem1 = ({ studentName, course, section }) => {
  return (
    <div>
      <h1>Student Information</h1>
      <p>Student Name: Reanne Ashley Matias {studentName}</p>
      <p>Course: BSIT {course}</p>
      <p>Section: 3B {section}</p>
    </div>
  );
};

export default Problem1;

